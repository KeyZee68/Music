package com.vortera27.app.data.remote

import com.google.gson.annotations.SerializedName
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

data class AudiusResponse(val data: List<AudiusTrack>?)
data class AudiusTrack(val id: String?, val title: String?, val duration: Long?,
                       val artwork: AudiusArtwork?, val user: AudiusUser?)
data class AudiusArtwork(@SerializedName("480x480") val big: String?, @SerializedName("150x150") val small: String?)
data class AudiusUser(val name: String?)

interface AudiusApi {
    @GET("v1/tracks/trending")
    suspend fun trending(@Query("app_name") app: String, @Query("limit") limit: Int): AudiusResponse

    @GET("v1/tracks/search")
    suspend fun search(@Query("query") q: String, @Query("app_name") app: String, @Query("limit") limit: Int): AudiusResponse

    companion object {
        const val APP = "Vortera27"
        val instance: AudiusApi by lazy {
            Retrofit.Builder().baseUrl("https://api.audius.co/")
                .addConverterFactory(GsonConverterFactory.create()).build().create(AudiusApi::class.java)
        }
    }
}
