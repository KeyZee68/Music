package com.vortera27.app.data.local

import android.content.Context
import androidx.room.*
import com.vortera27.app.domain.model.MediaItem
import com.vortera27.app.domain.model.MediaType
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "media_cache")
data class MediaEntity(
    @PrimaryKey val id: String, val title: String, val artist: String, val coverUrl: String,
    val mediaUrl: String, val type: String, val duration: Long,
    val liked: Boolean = false, val lastPlayed: Long = 0, val playCount: Int = 0
)
@Entity(tableName = "playlist")
data class PlaylistEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String,
                          val createdAt: Long = System.currentTimeMillis())
@Entity(tableName = "playlist_item", primaryKeys = ["playlistId", "mediaId"])
data class PlaylistItemEntity(val playlistId: Long, val mediaId: String, val position: Int)
data class PlaylistCount(val playlistId: Long, val n: Int)

@Dao
interface MediaDao {
    @Query("SELECT * FROM media_cache WHERE id = :id") suspend fun get(id: String): MediaEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(e: MediaEntity)
    @Query("SELECT * FROM media_cache WHERE liked = 1 ORDER BY title") fun liked(): Flow<List<MediaEntity>>
    @Query("SELECT * FROM media_cache WHERE lastPlayed > 0 ORDER BY lastPlayed DESC LIMIT 50") fun history(): Flow<List<MediaEntity>>
    @Query("SELECT * FROM playlist ORDER BY createdAt DESC") fun playlists(): Flow<List<PlaylistEntity>>
    @Insert suspend fun insertPlaylist(p: PlaylistEntity): Long
    @Query("DELETE FROM playlist WHERE id = :id") suspend fun deletePlaylist(id: Long)
    @Query("DELETE FROM playlist_item WHERE playlistId = :id") suspend fun clearPlaylist(id: Long)
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun addItem(i: PlaylistItemEntity)
    @Query("SELECT COUNT(*) FROM playlist_item WHERE playlistId = :id") suspend fun count(id: Long): Int
    @Query("SELECT m.* FROM media_cache m INNER JOIN playlist_item p ON m.id = p.mediaId WHERE p.playlistId = :id ORDER BY p.position")
    fun items(id: Long): Flow<List<MediaEntity>>
    @Query("SELECT playlistId, COUNT(*) AS n FROM playlist_item GROUP BY playlistId") fun counts(): Flow<List<PlaylistCount>>
}

@Database(entities = [MediaEntity::class, PlaylistEntity::class, PlaylistItemEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): MediaDao
    companion object {
        @Volatile private var inst: AppDatabase? = null
        fun get(ctx: Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, "vortera.db").build().also { inst = it }
        }
    }
}

fun MediaItem.toEntity() = MediaEntity(id, title, artist, coverUrl, mediaUrl, type.name, duration)
fun MediaEntity.toDomain() = MediaItem(id, title, artist, coverUrl, mediaUrl, MediaType.valueOf(type), duration)
