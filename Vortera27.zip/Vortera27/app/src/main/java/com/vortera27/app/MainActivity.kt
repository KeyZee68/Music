package com.vortera27.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.background
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.Alignment
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.vortera27.app.presentation.PlayerViewModel
import com.vortera27.app.presentation.components.BottomNav
import com.vortera27.app.presentation.components.MiniPlayer
import com.vortera27.app.presentation.screens.*
import com.vortera27.app.presentation.theme.Vortera27Theme

class MainActivity : ComponentActivity() {
    private val vm: PlayerViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.parseColor("#0B0F19")
        window.navigationBarColor = android.graphics.Color.parseColor("#0B0F19")
        setContent {
            Vortera27Theme {
                var tab by remember { mutableIntStateOf(0) }
                var showPlayer by remember { mutableStateOf(false) }
                val homeState = rememberLazyListState()
                androidx.activity.compose.BackHandler(tab != 0) { tab = 0 }
                androidx.activity.compose.BackHandler(showPlayer) { showPlayer = false }
                Box(Modifier.fillMaxSize()) {
                Scaffold(containerColor = Color(0xFF0B0F19), bottomBar = {
                    Column { MiniPlayer(vm) { showPlayer = true }; BottomNav(tab) { tab = it } }
                }) { pad ->
                    Box(Modifier.padding(pad)) {
                        when (tab) {
                            0 -> HomeScreen(vm, { showPlayer = true }, homeState)
                            1 -> ExploreScreen(vm) { showPlayer = true }
                            else -> LibraryScreen(vm) { showPlayer = true }
                        }
                    }
                }
                if (showPlayer) PlayerScreen(vm) { showPlayer = false }
                vm.notice?.let { n -> AlertDialog(onDismissRequest = { vm.clearNotice() }, title = { Text("Info") },
                    text = { Text(n) }, confirmButton = { TextButton({ vm.clearNotice() }) { Text("OK") } }) }
                }
            }
        }
    }

}
