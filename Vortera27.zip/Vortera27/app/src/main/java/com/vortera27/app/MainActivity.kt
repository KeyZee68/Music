package com.vortera27.app

import android.Manifest
import android.app.PictureInPictureParams
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.vortera27.app.domain.model.MediaType
import com.vortera27.app.presentation.PlayerViewModel
import com.vortera27.app.presentation.components.BottomNav
import com.vortera27.app.presentation.components.MiniPlayer
import com.vortera27.app.presentation.screens.*
import com.vortera27.app.presentation.theme.Vortera27Theme

class MainActivity : ComponentActivity() {
    private val vm: PlayerViewModel by viewModels()
    private var inPip by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.parseColor("#0B0F19")
        window.navigationBarColor = android.graphics.Color.parseColor("#0B0F19")
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent {
            Vortera27Theme {
                var tab by remember { mutableIntStateOf(0) }
                var showPlayer by remember { mutableStateOf(false) }
                val homeState = rememberLazyListState()
                if (inPip) { PlayerScreenPip(vm); return@Vortera27Theme }
                androidx.activity.compose.BackHandler(tab != 0) { tab = 0 }
                androidx.activity.compose.BackHandler(showPlayer) { showPlayer = false }
                androidx.activity.compose.BackHandler(vm.youtube != null) { vm.closeYoutube() }
                Box(Modifier.fillMaxSize()) {
                Scaffold(containerColor = Color(0xFF0B0F19), bottomBar = {
                    Column { MiniPlayer(vm) { showPlayer = true }; BottomNav(tab) { tab = it } }
                }) { pad ->
                    Box(Modifier.padding(pad)) {
                        when (tab) {
                            0 -> HomeScreen(vm, { showPlayer = true }, homeState)
                            1 -> ExploreScreen(vm) { showPlayer = true }
                            else -> LibraryScreen(vm) { showPlayer = true }
                        }
                    }
                }
                if (showPlayer) PlayerScreen(vm) { showPlayer = false }
                vm.youtube?.let { yt -> YouTubeScreen(vm, yt) { vm.closeYoutube() } }
                }
            }
        }
    }

    // Video tetap tampil di jendela mengambang saat pengguna keluar dari aplikasi
    override fun onUserLeaveHint() {
        val c = vm.current
        if (Build.VERSION.SDK_INT >= 26 && c?.type == MediaType.VIDEO && vm.isPlaying && !vm.audioOnly)
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
    }
    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
    }
}

@Composable
private fun PlayerScreenPip(vm: PlayerViewModel) {
    val c = vm.controller ?: return
    androidx.compose.ui.viewinterop.AndroidView({ ctx ->
        androidx.media3.ui.PlayerView(ctx).apply { player = c; useController = false } }, Modifier.fillMaxSize())
}
