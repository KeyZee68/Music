package com.vortera27.app.domain.model

data class MediaItem(
    val id: String, val title: String, val artist: String,
    val coverUrl: String, val mediaUrl: String, val type: MediaType, val duration: Long
)
enum class MediaType { AUDIO, VIDEO }
