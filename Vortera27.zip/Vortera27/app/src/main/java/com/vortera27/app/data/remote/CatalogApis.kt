package com.vortera27.app.data.remote

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

// ---------- Deezer: katalog besar, tanpa API key, cuplikan 30 detik ----------
data class DzList<T>(val data: List<T>?)
data class DzArtist(val name: String?)
data class DzAlbum(val cover_big: String?, val cover_medium: String?)
data class DzTrack(val id: Long?, val title: String?, val duration: Long?, val preview: String?,
                   val artist: DzArtist?, val album: DzAlbum?)
data class DzPlaylist(val id: Long?, val title: String?)

interface DeezerApi {
    @GET("chart/0/tracks") suspend fun chart(@Query("limit") n: Int): DzList<DzTrack>
    @GET("search") suspend fun search(@Query("q") q: String, @Query("limit") n: Int): DzList<DzTrack>
    @GET("search/playlist") suspend fun searchPlaylist(@Query("q") q: String, @Query("limit") n: Int): DzList<DzPlaylist>
    @GET("playlist/{id}/tracks") suspend fun playlistTracks(@Path("id") id: Long, @Query("limit") n: Int): DzList<DzTrack>
    companion object {
        val instance: DeezerApi by lazy {
            Retrofit.Builder().baseUrl("https://api.deezer.com/")
                .addConverterFactory(GsonConverterFactory.create()).build().create(DeezerApi::class.java)
        }
    }
}

// ---------- YouTube Data API v3 (resmi, butuh API key gratis) ----------
data class YtThumb(val url: String?)
data class YtThumbs(val high: YtThumb?, val medium: YtThumb?)
data class YtSnippet(val title: String?, val channelTitle: String?, val thumbnails: YtThumbs?)
data class YtId(val videoId: String?)
data class YtItem(val id: YtId?, val snippet: YtSnippet?)
data class YtResponse(val items: List<YtItem>?)

interface YouTubeApi {
    @GET("youtube/v3/search")
    suspend fun search(@Query("part") part: String, @Query("type") type: String,
                       @Query("videoCategoryId") cat: String, @Query("maxResults") n: Int,
                       @Query("q") q: String, @Query("key") key: String): YtResponse
    companion object {
        val instance: YouTubeApi by lazy {
            Retrofit.Builder().baseUrl("https://www.googleapis.com/")
                .addConverterFactory(GsonConverterFactory.create()).build().create(YouTubeApi::class.java)
        }
    }
}
