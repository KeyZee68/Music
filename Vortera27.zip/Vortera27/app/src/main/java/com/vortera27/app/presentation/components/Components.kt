package com.vortera27.app.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.vortera27.app.domain.model.MediaItem
import com.vortera27.app.domain.model.MediaType
import com.vortera27.app.presentation.PlayerViewModel
import com.vortera27.app.presentation.theme.*

val TileColor = Color(0xFF1A2236)

@Composable
fun Cover(url: String, size: Dp, radius: Dp = 6.dp) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val req = remember(url) { coil.request.ImageRequest.Builder(ctx).data(url.ifBlank { null }).crossfade(true).build() }
    AsyncImage(req, null, Modifier.size(size).clip(RoundedCornerShape(radius)),
        placeholder = androidx.compose.ui.graphics.painter.ColorPainter(TileColor),
        error = androidx.compose.ui.graphics.painter.ColorPainter(TileColor), contentScale = ContentScale.Crop)
}

@Composable
fun QuickTile(item: MediaItem, modifier: Modifier, onClick: () -> Unit) {
    Row(modifier.clip(RoundedCornerShape(6.dp)).background(TileColor).clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically) {
        Cover(item.coverUrl, 56.dp, 0.dp)
        Text(item.title, Modifier.padding(horizontal = 10.dp), maxLines = 2, overflow = TextOverflow.Ellipsis,
            fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun MediaCard(item: MediaItem, onClick: () -> Unit) {
    Column(Modifier.width(140.dp).clickable(onClick = onClick)) {
        Box {
            Cover(item.coverUrl, 140.dp, 8.dp)
            if (item.type == MediaType.VIDEO)
                Icon(Icons.Filled.Videocam, null, tint = VorteraCyan, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp))
        }
        Text(item.title, Modifier.padding(top = 6.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        Text(item.artist, color = VorteraTextSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun MediaRow(item: MediaItem, vm: PlayerViewModel, onClick: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var picker by remember { mutableStateOf(false) }
    val liked = item.id in vm.likedIds
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Cover(item.coverUrl, 52.dp)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(item.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (vm.current?.id == item.id) VorteraCyan else Color.White)
            Text(item.artist + tag(item), color = VorteraTextSecondary,
                fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton({ vm.toggleLike(item) }) {
            Icon(if (liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null,
                tint = if (liked) VorteraCyan else VorteraTextSecondary)
        }
        Box {
            IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, null, tint = VorteraTextSecondary) }
            DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem(text = { Text("Tambah ke playlist") }, onClick = { menu = false; picker = true })
            }
        }
    }
    if (picker) PlaylistPicker(vm, item) { picker = false }
}

@Composable
fun PlaylistPicker(vm: PlayerViewModel, item: MediaItem, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, containerColor = VorteraSurface,
        title = { Text("Tambah ke playlist") },
        text = {
            Column {
                vm.playlists.forEach { p ->
                    TextButton({ vm.addToPlaylist(p, item); onDismiss() }) { Text(p.name, color = Color.White) }
                }
                OutlinedTextField(name, { name = it }, placeholder = { Text("Playlist baru") }, singleLine = true)
            }
        },
        confirmButton = { TextButton({ if (name.isNotBlank()) vm.createPlaylist(name.trim(), item); onDismiss() }) { Text("Buat", color = VorteraCyan) } },
        dismissButton = { TextButton(onDismiss) { Text("Batal") } })
}

@Composable
fun MiniPlayer(vm: PlayerViewModel, onOpen: () -> Unit) {
    val item = vm.current ?: return
    Column(Modifier.padding(horizontal = 8.dp, vertical = 4.dp).clip(RoundedCornerShape(10.dp))
        .background(Color(0xFF2A1B4D)).clickable(onClick = onOpen)) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Cover(item.coverUrl, 44.dp)
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(item.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text(item.artist, color = VorteraTextSecondary, fontSize = 12.sp, maxLines = 1)
            }
            IconButton({ vm.toggleLike(item) }) {
                val l = item.id in vm.likedIds
                Icon(if (l) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, tint = if (l) VorteraCyan else Color.White)
            }
            IconButton(vm::toggle) { Icon(if (vm.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = Color.White) }
        }
        LinearProgressIndicator(progress = { if (vm.duration > 0) vm.position.toFloat() / vm.duration else 0f },
            modifier = Modifier.fillMaxWidth().height(2.dp), color = Color.White, trackColor = Color.White.copy(alpha = 0.2f))
    }
}

@Composable
fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = VorteraBackground.copy(alpha = 0.97f)) {
        listOf("Beranda" to Icons.Filled.Home, "Cari" to Icons.Filled.Search, "Koleksi" to Icons.Filled.LibraryMusic)
            .forEachIndexed { i, (l, ic) ->
                NavigationBarItem(selected == i, { onSelect(i) }, { Icon(ic, l) }, label = { Text(l) },
                    colors = NavigationBarItemDefaults.colors(selectedIconColor = VorteraCyan, selectedTextColor = VorteraCyan,
                        indicatorColor = Color.Transparent, unselectedIconColor = VorteraTextSecondary, unselectedTextColor = VorteraTextSecondary))
            }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(selected, onClick, label = { Text(text) }, colors = FilterChipDefaults.filterChipColors(
        selectedContainerColor = VorteraCyan, selectedLabelColor = Color.Black,
        containerColor = TileColor, labelColor = Color.White))
}

fun tag(i: MediaItem): String = when {
    i.type == MediaType.VIDEO -> " • Video"
    i.type == MediaType.YOUTUBE -> " • YouTube"
    i.id.startsWith("dz_") -> " • Preview 30 dtk"
    else -> ""
}
