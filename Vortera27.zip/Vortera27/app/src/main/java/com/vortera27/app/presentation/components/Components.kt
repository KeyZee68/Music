package com.vortera27.app.presentation.components

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.vortera27.app.domain.model.MediaItem
import com.vortera27.app.domain.model.MediaType
import com.vortera27.app.presentation.PlayerViewModel
import com.vortera27.app.presentation.theme.*

@Composable
fun Modifier.glass(r: Int = 16) = this.clip(RoundedCornerShape(r.dp)).background(GlassBrush)
    .border(1.dp, GlassBorder, RoundedCornerShape(r.dp))

@Composable
fun MediaCard(item: MediaItem, onClick: () -> Unit) {
    Column(Modifier.width(140.dp).clickable(onClick = onClick)) {
        Box {
            AsyncImage(item.coverUrl, item.title, Modifier.size(140.dp).clip(RoundedCornerShape(14.dp)),
                contentScale = ContentScale.Crop)
            if (item.type == MediaType.VIDEO)
                Icon(Icons.Filled.Videocam, null, tint = VorteraCyan,
                    modifier = Modifier.align(Alignment.TopEnd).padding(6.dp))
        }
        Text(item.title, Modifier.padding(top = 6.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(item.artist, color = VorteraTextSecondary, style = MaterialTheme.typography.bodySmall, maxLines = 1)
    }
}

@Composable
fun MediaRow(item: MediaItem, vm: PlayerViewModel, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).glass(12).clickable(onClick = onClick).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(item.coverUrl, null, Modifier.size(52.dp).clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Crop)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(item.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(item.artist + if (item.type == MediaType.VIDEO) " • Video" else "",
                color = VorteraTextSecondary, style = MaterialTheme.typography.bodySmall)
        }
        IconButton({ vm.toggleLike(item) }) {
            Icon(if (item.id in vm.liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null,
                tint = if (item.id in vm.liked) VorteraCyan else VorteraTextSecondary)
        }
    }
}

@Composable
fun MiniPlayer(vm: PlayerViewModel, onOpen: () -> Unit) {
    val item = vm.current ?: return
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp).glass(14)
        .clickable(onClick = onOpen).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(item.coverUrl, null, Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Crop)
        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
            Text(item.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(item.artist, color = VorteraTextSecondary, style = MaterialTheme.typography.bodySmall)
        }
        IconButton(vm::toggle) {
            Icon(if (vm.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, tint = VorteraCyan)
        }
    }
}

@Composable
fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = VorteraBackground) {
        listOf("Beranda" to Icons.Filled.Home, "Jelajah" to Icons.Filled.Search,
            "Koleksi" to Icons.Filled.LibraryMusic).forEachIndexed { i, (l, ic) ->
            NavigationBarItem(selected == i, { onSelect(i) }, { Icon(ic, l) }, label = { Text(l) },
                colors = NavigationBarItemDefaults.colors(selectedIconColor = Color0, selectedTextColor = VorteraCyan,
                    indicatorColor = VorteraPurple.copy(alpha = 0.35f), unselectedIconColor = VorteraTextSecondary,
                    unselectedTextColor = VorteraTextSecondary))
        }
    }
}
private val Color0 = VorteraCyan
