package com.vortera27.app.presentation.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vortera27.app.R
import com.vortera27.app.data.local.PlaylistEntity
import com.vortera27.app.data.repository.MediaRepository
import com.vortera27.app.domain.model.MediaItem
import com.vortera27.app.domain.model.MediaType
import com.vortera27.app.presentation.PlayerViewModel
import com.vortera27.app.presentation.components.*
import com.vortera27.app.presentation.theme.*
import kotlinx.coroutines.delay
import java.util.Calendar

private fun PlayerViewModel.start(m: MediaItem, list: List<MediaItem>, onPlay: () -> Unit) {
    play(m, list); if (m.type == MediaType.VIDEO) onPlay()
}

private fun greeting(): String = when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
    in 4..10 -> "Selamat pagi"; in 11..14 -> "Selamat siang"; in 15..17 -> "Selamat sore"; else -> "Selamat malam"
}

@Composable
private fun Section(title: String, list: List<MediaItem>, onClick: (MediaItem) -> Unit) {
    if (list.isEmpty()) return
    Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 22.dp, bottom = 10.dp))
    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) { items(list) { MediaCard(it) { onClick(it) } } }
}

@Composable
fun HomeScreen(vm: PlayerViewModel, onPlay: () -> Unit, listState: LazyListState = rememberLazyListState()) {
    var filter by remember { mutableIntStateOf(0) }
    val videos = MediaRepository.videos
    val music = (vm.indo + vm.viral + vm.trending + vm.indie).distinctBy { it.id }
    val pool = when (filter) { 1 -> music; 2 -> videos; else -> music + videos }
    val uri = LocalUriHandler.current
    LazyColumn(Modifier.fillMaxSize()
        .background(Brush.verticalGradient(listOf(VorteraPurple.copy(alpha = 0.35f), VorteraBackground), endY = 800f))
        .padding(horizontal = 16.dp), state = listState) {
        item {
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.logo_v), null, Modifier.size(40.dp))
                Column(Modifier.padding(start = 10.dp)) {
                    Text(greeting(), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Vortera27 • by BayXD", color = VorteraCyan, fontSize = 11.sp)
                }
            }
            vm.updateUrl?.let { url ->
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(VorteraGradient)
                    .clickable { uri.openUri(url) }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.SystemUpdate, null, tint = Color.Black)
                    Text("Versi baru tersedia — ketuk untuk update", Modifier.padding(start = 10.dp), color = Color.Black, fontWeight = FontWeight.SemiBold)
                }
            }
            Row(Modifier.padding(vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Semua", filter == 0) { filter = 0 }; Chip("Musik", filter == 1) { filter = 1 }; Chip("Video", filter == 2) { filter = 2 }
            }
            if (pool.isEmpty() && vm.loading) repeat(3) {
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    repeat(2) { Box(Modifier.weight(1f).height(56.dp).clip(RoundedCornerShape(6.dp)).background(TileColor)) }
                }
            }
            pool.take(6).chunked(2).forEach { pair ->
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    pair.forEach { m -> QuickTile(m, Modifier.weight(1f)) { vm.start(m, pool, onPlay) } }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            if (vm.loading) Box(Modifier.fillMaxWidth().height(120.dp), Alignment.Center) { CircularProgressIndicator(color = VorteraCyan) }
            vm.error?.let {
                Text(it, color = VorteraTextSecondary)
                TextButton({ vm.loadTrending() }) { Text("Coba lagi", color = VorteraCyan) }
            }
        }
        item { Section("Terakhir diputar", vm.history) { vm.start(it, vm.history, onPlay) } }
        item { Section("Hits Indonesia", vm.indo) { vm.start(it, vm.indo, onPlay) } }
        item { Section("Chart Teratas", vm.trending) { vm.start(it, vm.trending, onPlay) } }
        item { Section("Viral TikTok", vm.viral) { vm.start(it, vm.viral, onPlay) } }
        item { Section("Indie Trending (lagu penuh)", vm.indie) { vm.start(it, vm.indie, onPlay) } }
        item { Section("Video Pilihan", videos) { vm.start(it, videos, onPlay) } }
        item {
            Text("Vortera27 • by BayXD", color = VorteraTextSecondary, fontSize = 11.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(vertical = 28.dp))
        }
    }
}

private val categories = listOf("Pop" to 0xFFE13300, "Hip-Hop" to 0xFFBA5D07, "Elektronik" to 0xFF1E3264, "Lo-fi" to 0xFF608108,
    "Chill" to 0xFF477D95, "Indonesia" to 0xFFB91C1C, "Dangdut" to 0xFF0E7490, "K-Pop" to 0xFFBE185D, "Galau" to 0xFF4C1D95, "Rock" to 0xFF8D1C1C, "Jazz" to 0xFF7D4B32, "Akustik" to 0xFF503750)

@Composable
fun ExploreScreen(vm: PlayerViewModel, onPlay: () -> Unit) {
    var q by rememberSaveable { mutableStateOf("") }
    var src by rememberSaveable { mutableStateOf(0) }
    LaunchedEffect(q, src) { delay(400); vm.search(q, src) }
    val hint = listOf("Jutaan lagu • cuplikan 30 detik, bisa diputar di latar belakang",
        "Lagu lengkap lewat pemutar resmi YouTube (layar harus menyala)",
        "Musik independen • lagu penuh")[src]
    LazyColumn(Modifier.fillMaxSize().background(VorteraBackground).padding(horizontal = 16.dp)) {
        item {
            Spacer(Modifier.height(16.dp))
            Text("Cari", fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            TextField(q, { q = it }, Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)), singleLine = true,
                placeholder = { Text("Lagu, artis, atau yang lagi viral") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = { if (q.isNotEmpty()) IconButton({ q = "" }) { Icon(Icons.Filled.Close, null) } },
                colors = TextFieldDefaults.colors(focusedContainerColor = TileColor, unfocusedContainerColor = TileColor,
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent))
            Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Katalog", src == 0) { src = 0 }; Chip("YouTube", src == 1) { src = 1 }; Chip("Indie", src == 2) { src = 2 }
            }
            Text(hint, color = VorteraTextSecondary, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp, bottom = 10.dp))
            vm.error?.let { Text(it, color = VorteraCyan, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp)) }
            if (vm.searching) LinearProgressIndicator(Modifier.fillMaxWidth().padding(bottom = 8.dp), color = VorteraCyan)
            if (q.isNotBlank() && !vm.searching && vm.results.isEmpty() && vm.error == null)
                Text("Tidak ada hasil untuk \"$q\". Coba sumber lain di atas.", color = VorteraTextSecondary, modifier = Modifier.padding(bottom = 8.dp))
            if (q.isBlank()) Text("Jelajahi semua", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 10.dp))
        }
        if (q.isBlank()) {
            items(categories.chunked(2)) { pair ->
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    pair.forEach { (name, c) ->
                        Box(Modifier.weight(1f).height(90.dp).clip(RoundedCornerShape(8.dp)).background(Color(c))
                            .clickable { q = name }.padding(12.dp)) { Text(name, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                    }
                }
            }
        } else items(vm.results) { m -> MediaRow(m, vm) { vm.start(m, vm.results, onPlay) } }
    }
}

@Composable
fun LibraryScreen(vm: PlayerViewModel, onPlay: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<PlaylistEntity?>(null) }
    var create by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    androidx.activity.compose.BackHandler(open != null) { open = null }
    open?.let { PlaylistDetail(vm, it, { open = null }, onPlay); return }
    Column(Modifier.fillMaxSize().background(VorteraBackground).padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Koleksi Kamu", fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton({ create = true }) { Icon(Icons.Filled.Add, null) }
        }
        Row(Modifier.padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Playlist", tab == 0) { tab = 0 }; Chip("Disukai", tab == 1) { tab = 1 }; Chip("Riwayat", tab == 2) { tab = 2 }
        }
        LazyColumn {
            when (tab) {
                0 -> {
                    item {
                        Row(Modifier.fillMaxWidth().clickable { tab = 1 }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(52.dp).clip(RoundedCornerShape(6.dp)).background(VorteraGradient), Alignment.Center) {
                                Icon(Icons.Filled.Favorite, null, tint = Color.White) }
                            Column(Modifier.padding(start = 12.dp)) {
                                Text("Lagu yang Disukai", fontWeight = FontWeight.SemiBold)
                                Text("${vm.likedList.size} lagu", color = VorteraTextSecondary, fontSize = 12.sp)
                            }
                        }
                    }
                    items(vm.playlists) { p ->
                        Row(Modifier.fillMaxWidth().clickable { open = p }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(52.dp).clip(RoundedCornerShape(6.dp)).background(TileColor), Alignment.Center) {
                                Icon(Icons.Filled.QueueMusic, null, tint = VorteraCyan) }
                            Column(Modifier.padding(start = 12.dp)) {
                                Text(p.name, fontWeight = FontWeight.SemiBold)
                                Text("Playlist • ${vm.counts[p.id] ?: 0} lagu", color = VorteraTextSecondary, fontSize = 12.sp)
                            }
                        }
                    }
                }
                1 -> {
                    if (vm.likedList.isEmpty()) item { Text("Ketuk ♥ pada lagu untuk menyimpannya di sini.", color = VorteraTextSecondary) }
                    items(vm.likedList) { m -> MediaRow(m, vm) { vm.start(m, vm.likedList, onPlay) } }
                }
                else -> {
                    if (vm.history.isEmpty()) item { Text("Belum ada riwayat putar.", color = VorteraTextSecondary) }
                    items(vm.history) { m -> MediaRow(m, vm) { vm.start(m, vm.history, onPlay) } }
                }
            }
        }
    }
    if (create) AlertDialog(onDismissRequest = { create = false }, containerColor = VorteraSurface,
        title = { Text("Playlist baru") },
        text = { OutlinedTextField(name, { name = it }, singleLine = true, placeholder = { Text("Nama playlist") }) },
        confirmButton = { TextButton({ if (name.isNotBlank()) vm.createPlaylist(name.trim()); name = ""; create = false }) { Text("Buat", color = VorteraCyan) } },
        dismissButton = { TextButton({ create = false }) { Text("Batal") } })
}

@Composable
private fun PlaylistDetail(vm: PlayerViewModel, p: PlaylistEntity, onBack: () -> Unit, onPlay: () -> Unit) {
    val items by remember(p.id) { vm.playlistItems(p.id) }.collectAsState(initial = emptyList())
    Column(Modifier.fillMaxSize().background(VorteraBackground).padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Filled.ArrowBack, null) }
            Text(p.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton({ vm.deletePlaylist(p); onBack() }) { Icon(Icons.Filled.Delete, null, tint = VorteraTextSecondary) }
        }
        Row(Modifier.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${items.size} lagu", color = VorteraTextSecondary, modifier = Modifier.weight(1f))
            if (items.isNotEmpty()) Box(Modifier.size(52.dp).clip(RoundedCornerShape(26.dp)).background(VorteraGradient)
                .clickable { vm.start(items[0], items, onPlay) }, Alignment.Center) {
                Icon(Icons.Filled.PlayArrow, null, tint = Color.Black, modifier = Modifier.size(32.dp)) }
        }
        LazyColumn { items(items) { m -> MediaRow(m, vm) { vm.start(m, items, onPlay) } } }
    }
}
