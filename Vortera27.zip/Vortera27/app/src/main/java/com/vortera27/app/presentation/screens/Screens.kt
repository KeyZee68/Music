package com.vortera27.app.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vortera27.app.data.repository.MediaRepository
import com.vortera27.app.domain.model.MediaItem
import com.vortera27.app.domain.model.MediaType
import com.vortera27.app.presentation.PlayerViewModel
import com.vortera27.app.presentation.components.*
import com.vortera27.app.presentation.theme.*
import kotlinx.coroutines.delay

private fun PlayerViewModel.start(m: MediaItem, list: List<MediaItem>, onPlay: () -> Unit) {
    play(m, list); if (m.type == MediaType.VIDEO) onPlay()
}

@Composable
fun HomeScreen(vm: PlayerViewModel, onPlay: () -> Unit) {
    val videos = MediaRepository.videos
    val all = vm.trending + videos
    LazyColumn(Modifier.fillMaxSize().background(VorteraBackground).padding(horizontal = 16.dp)) {
        item {
            Spacer(Modifier.height(24.dp))
            Text("Vortera27", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = VorteraCyan)
            Text("by BayXD", color = VorteraPurple, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(16.dp))
            Text("Trending Sekarang", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            if (vm.loading) Box(Modifier.fillMaxWidth().height(160.dp), Alignment.Center) {
                CircularProgressIndicator(color = VorteraCyan) }
            vm.error?.let {
                Text(it, color = VorteraTextSecondary)
                TextButton({ vm.loadTrending() }) { Text("Coba lagi", color = VorteraCyan) }
            }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(vm.trending) { s -> MediaCard(s) { vm.start(s, vm.trending, onPlay) } }
            }
            Spacer(Modifier.height(20.dp))
            Text("Video Pilihan", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(videos) { v -> MediaCard(v) { vm.start(v, videos, onPlay) } }
            }
            Spacer(Modifier.height(20.dp))
            Text("Semua Media", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
        }
        items(all) { m -> MediaRow(m, vm) { vm.start(m, all, onPlay) } }
        item {
            Text("Vortera27 • by BayXD", color = VorteraTextSecondary, fontSize = 11.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp))
        }
    }
}

@Composable
fun ExploreScreen(vm: PlayerViewModel, onPlay: () -> Unit) {
    var q by remember { mutableStateOf("") }
    LaunchedEffect(q) { delay(400); vm.search(q) }
    val list = if (q.isBlank()) vm.trending else vm.results
    Column(Modifier.fillMaxSize().background(VorteraBackground).padding(16.dp)) {
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = { Text("Cari lagu atau artis") },
            singleLine = true, shape = RoundedCornerShape(24.dp))
        Spacer(Modifier.height(12.dp))
        LazyColumn { items(list) { m -> MediaRow(m, vm) { vm.start(m, list, onPlay) } } }
    }
}

@Composable
fun LibraryScreen(vm: PlayerViewModel, onPlay: () -> Unit) {
    val liked = vm.liked.values.toList()
    Column(Modifier.fillMaxSize().background(VorteraBackground).padding(16.dp)) {
        Spacer(Modifier.height(16.dp))
        Text("Koleksi Disukai", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if (liked.isEmpty()) Text("Ketuk ♥ pada lagu untuk menyimpannya di sini.", color = VorteraTextSecondary)
        LazyColumn { items(liked) { m -> MediaRow(m, vm) { vm.start(m, liked, onPlay) } } }
    }
}
