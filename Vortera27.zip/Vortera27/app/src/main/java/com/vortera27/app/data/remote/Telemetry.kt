package com.vortera27.app.data.remote

import android.content.Context
import com.vortera27.app.BuildConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*
import java.util.UUID

data class EventDto(val device_id: String, val event: String, val detail: String, val app_version: String)
data class GhAsset(val browser_download_url: String?)
data class GhRelease(val tag_name: String?, val assets: List<GhAsset>?)

interface SupabaseApi {
    @Headers("Prefer: return=minimal")
    @POST("rest/v1/events")
    suspend fun insert(@Header("apikey") key: String, @Header("Authorization") auth: String, @Body e: EventDto): Response<Unit>
}
interface GithubApi {
    @GET("repos/KeyZee68/Music/releases/latest") suspend fun latest(): GhRelease
}

/** Kirim event penggunaan ke Supabase (opsional) dan cek update dari GitHub Releases. */
object Telemetry {
    private var deviceId = "unknown"
    fun init(ctx: Context) {
        val sp = ctx.getSharedPreferences("v27", 0)
        deviceId = sp.getString("did", null) ?: UUID.randomUUID().toString().also { sp.edit().putString("did", it).apply() }
    }
    private val api by lazy {
        Retrofit.Builder().baseUrl(BuildConfig.SUPABASE_URL.trimEnd('/') + "/")
            .addConverterFactory(GsonConverterFactory.create()).build().create(SupabaseApi::class.java)
    }
    fun log(event: String, detail: String = "") {
        if (BuildConfig.SUPABASE_URL.isBlank() || BuildConfig.SUPABASE_KEY.isBlank()) return
        CoroutineScope(Dispatchers.IO).launch {
            try { api.insert(BuildConfig.SUPABASE_KEY, "Bearer ${BuildConfig.SUPABASE_KEY}",
                EventDto(deviceId, event, detail.take(200), BuildConfig.VERSION_NAME)) } catch (_: Exception) {}
        }
    }
    val github: GithubApi by lazy {
        Retrofit.Builder().baseUrl("https://api.github.com/")
            .addConverterFactory(GsonConverterFactory.create()).build().create(GithubApi::class.java)
    }
}
