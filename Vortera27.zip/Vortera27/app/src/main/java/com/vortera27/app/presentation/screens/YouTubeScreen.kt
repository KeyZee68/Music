package com.vortera27.app.presentation.screens

import android.annotation.SuppressLint
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.vortera27.app.domain.model.MediaItem
import com.vortera27.app.presentation.PlayerViewModel
import com.vortera27.app.presentation.theme.*

/** Pemutar resmi YouTube (embed). Layar harus menyala; tidak bisa jalan di latar belakang (aturan YouTube). */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubeScreen(vm: PlayerViewModel, item: MediaItem, onClose: () -> Unit) {
    val liked = item.id in vm.likedIds
    val uri = LocalUriHandler.current
    Column(Modifier.fillMaxSize().background(VorteraBackground).pointerInput(Unit) { detectTapGestures { } }) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClose) { Icon(Icons.Filled.KeyboardArrowDown, null, Modifier.size(32.dp)) }
            Text("YouTube • Lagu lengkap", Modifier.weight(1f), color = VorteraTextSecondary, fontSize = 12.sp)
        }
        key(item.mediaUrl) {
            AndroidView(factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    setBackgroundColor(android.graphics.Color.BLACK)
                    webChromeClient = WebChromeClient(); webViewClient = WebViewClient()
                    val html = "<html><body style='margin:0;background:#000;height:100%'>" +
                        "<iframe style='width:100%;height:100vh;border:0' " +
                        "src='https://www.youtube.com/embed/${item.mediaUrl}?autoplay=1&playsinline=1&rel=0' " +
                        "allow='autoplay; encrypted-media; picture-in-picture' allowfullscreen></iframe></body></html>"
                    loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "utf-8", null)
                }
            }, modifier = Modifier.fillMaxWidth().aspectRatio(16 / 9f), onRelease = { it.destroy() })
        }
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(item.title, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 3)
                Text(item.artist, color = VorteraTextSecondary)
            }
            IconButton({ vm.toggleLike(item) }) {
                Icon(if (liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null,
                    tint = if (liked) VorteraCyan else Color.White)
            }
        }
        TextButton({ uri.openUri("https://www.youtube.com/watch?v=${item.mediaUrl}") }, Modifier.padding(horizontal = 8.dp)) {
            Text("Video tidak muncul? Buka di aplikasi YouTube", color = VorteraCyan, fontSize = 13.sp)
        }
    }
}
