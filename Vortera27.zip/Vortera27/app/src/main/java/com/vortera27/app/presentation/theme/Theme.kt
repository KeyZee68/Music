package com.vortera27.app.presentation.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val VorteraCyan = Color(0xFF00F0FF)
val VorteraPurple = Color(0xFF9D00FF)
val VorteraBackground = Color(0xFF0B0F19)
val VorteraSurface = Color(0xFF131B2E)
val VorteraTextSecondary = Color(0xFF94A3B8)
val VorteraGradient = Brush.horizontalGradient(listOf(VorteraCyan, VorteraPurple))
val GlassBrush = Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.03f)))
val GlassBorder = Color.White.copy(alpha = 0.12f)

private val DarkColorScheme = darkColorScheme(
    primary = VorteraCyan, secondary = VorteraPurple, background = VorteraBackground,
    surface = VorteraSurface, onPrimary = Color.Black, onBackground = Color.White, onSurface = Color.White
)

@Composable
fun Vortera27Theme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = DarkColorScheme, content = content)
