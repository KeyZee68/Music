package com.vortera27.app.presentation

import android.app.Application
import android.content.ComponentName
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.vortera27.app.data.repository.MediaRepository
import com.vortera27.app.domain.model.MediaItem
import com.vortera27.app.service.VorteraPlaybackService
import kotlinx.coroutines.launch
import androidx.media3.common.MediaItem as ExoItem

class PlayerViewModel(app: Application) : AndroidViewModel(app) {
    var controller by mutableStateOf<MediaController?>(null); private set
    var current by mutableStateOf<MediaItem?>(null); private set
    var isPlaying by mutableStateOf(false); private set
    var audioOnly by mutableStateOf(false); private set
    val liked = mutableStateMapOf<String, MediaItem>()

    var trending by mutableStateOf<List<MediaItem>>(emptyList()); private set
    var results by mutableStateOf<List<MediaItem>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set
    private var queue: List<MediaItem> = emptyList()

    init {
        val token = SessionToken(app, ComponentName(app, VorteraPlaybackService::class.java))
        val f = MediaController.Builder(app, token).buildAsync()
        f.addListener({
            val c = f.get(); controller = c
            c.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(p: Boolean) { isPlaying = p }
                override fun onMediaItemTransition(m: ExoItem?, r: Int) {
                    queue.find { it.id == m?.mediaId }?.let { current = it }
                }
                override fun onPlayerError(e: androidx.media3.common.PlaybackException) {
                    error = "Gagal memutar: periksa koneksi internet"
                }
            })
        }, ContextCompat.getMainExecutor(app))
        loadTrending()
    }

    fun loadTrending() = viewModelScope.launch {
        loading = true; error = null
        try { trending = MediaRepository.trending() }
        catch (e: Exception) { error = "Gagal memuat musik. Periksa koneksi internet." }
        loading = false
    }

    fun search(q: String) = viewModelScope.launch {
        if (q.isBlank()) { results = emptyList(); return@launch }
        try { results = MediaRepository.search(q.trim()) }
        catch (e: Exception) { error = "Pencarian gagal." }
    }

    private fun toExo(m: MediaItem) = ExoItem.Builder().setMediaId(m.id).setUri(m.mediaUrl)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(m.title).setArtist(m.artist)
            .setArtworkUri(android.net.Uri.parse(m.coverUrl)).build()).build()

    fun play(item: MediaItem, list: List<MediaItem> = listOf(item)) {
        val c = controller ?: return
        queue = if (list.any { it.id == item.id }) list else listOf(item)
        current = item; error = null
        c.setMediaItems(queue.map(::toExo), queue.indexOfFirst { it.id == item.id }, 0L)
        applyAudioOnly(); c.prepare(); c.play()
    }
    fun toggle() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun next() { controller?.seekToNextMediaItem() }
    fun prev() { controller?.seekToPreviousMediaItem() }
    fun seek(ms: Long) { controller?.seekTo(ms) }
    fun toggleLike(m: MediaItem) { if (liked.containsKey(m.id)) liked.remove(m.id) else liked[m.id] = m }
    fun toggleAudioOnly() { audioOnly = !audioOnly; applyAudioOnly() }
    private fun applyAudioOnly() {
        controller?.let { it.trackSelectionParameters = it.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, audioOnly).build() }
    }
}
