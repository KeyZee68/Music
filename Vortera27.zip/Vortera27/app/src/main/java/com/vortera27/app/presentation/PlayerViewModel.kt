package com.vortera27.app.presentation

import android.app.Application
import android.content.ComponentName
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.vortera27.app.data.local.*
import com.vortera27.app.data.remote.Telemetry
import com.vortera27.app.data.repository.MediaRepository
import com.vortera27.app.domain.model.MediaItem
import com.vortera27.app.domain.model.MediaType
import com.vortera27.app.service.VorteraPlaybackService
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import androidx.media3.common.MediaItem as ExoItem

class PlayerViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()
    var notice by mutableStateOf<String?>(null); private set
    var controller by mutableStateOf<MediaController?>(null); private set
    var current by mutableStateOf<MediaItem?>(null); private set
    var isPlaying by mutableStateOf(false); private set
    var shuffle by mutableStateOf(false); private set
    var repeatAll by mutableStateOf(false); private set
    var buffering by mutableStateOf(false); private set
    var searching by mutableStateOf(false); private set
    var indo by mutableStateOf<List<MediaItem>>(emptyList()); private set
    private var searchJob: Job? = null
    var position by mutableLongStateOf(0L); private set
    var duration by mutableLongStateOf(0L); private set

    var trending by mutableStateOf<List<MediaItem>>(emptyList()); private set
    var results by mutableStateOf<List<MediaItem>>(emptyList()); private set
    var viral by mutableStateOf<List<MediaItem>>(emptyList()); private set
    var indie by mutableStateOf<List<MediaItem>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set

    var likedList by mutableStateOf<List<MediaItem>>(emptyList()); private set
    var likedIds by mutableStateOf<Set<String>>(emptySet()); private set
    var history by mutableStateOf<List<MediaItem>>(emptyList()); private set
    var playlists by mutableStateOf<List<PlaylistEntity>>(emptyList()); private set
    var counts by mutableStateOf<Map<Long, Int>>(emptyMap()); private set
    private var queue: List<MediaItem> = emptyList()

    init {
        Telemetry.init(app); Telemetry.log("app_open")
        val token = SessionToken(app, ComponentName(app, VorteraPlaybackService::class.java))
        val f = MediaController.Builder(app, token).buildAsync()
        f.addListener({
            val c = f.get(); controller = c
            c.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(p: Boolean) { isPlaying = p }
                override fun onPlaybackStateChanged(s: Int) { buffering = s == Player.STATE_BUFFERING }
                override fun onMediaItemTransition(m: ExoItem?, r: Int) {
                    queue.find { it.id == m?.mediaId }?.let { current = it; record(it) }
                }
                override fun onPlayerError(e: androidx.media3.common.PlaybackException) {
                    error = "Gagal memutar: periksa koneksi internet"; Telemetry.log("error", e.errorCodeName)
                }
            })
        }, ContextCompat.getMainExecutor(app))
        viewModelScope.launch { dao.liked().collect { l -> likedList = l.map { it.toDomain() }; likedIds = l.map { it.id }.toSet() } }
        viewModelScope.launch { dao.history().collect { l -> history = l.map { it.toDomain() } } }
        viewModelScope.launch { dao.playlists().collect { playlists = it } }
        viewModelScope.launch { dao.counts().collect { l -> counts = l.associate { it.playlistId to it.n } } }
        viewModelScope.launch { while (true) { delay(500); controller?.takeIf { isPlaying }?.let { position = it.currentPosition; duration = it.duration.coerceAtLeast(0L) } } }
        loadTrending()
    }

    fun loadTrending() = viewModelScope.launch {
        loading = true
        error = null
        try {
            coroutineScope {
                val chartTask = async { MediaRepository.chart() }
                val viralTask = async { MediaRepository.viral() }
                val indieTask = async { MediaRepository.indie() }
                val indoTask = async { MediaRepository.indo() }
                trending = chartTask.await()
                viral = viralTask.await()
                indie = indieTask.await()
                indo = indoTask.await()
            }
            if (trending.isEmpty() && viral.isEmpty() && indie.isEmpty() && indo.isEmpty())
                error = "Belum ada katalog yang dapat dimuat. Coba lagi nanti."
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (_: Exception) {
            error = "Gagal memuat musik. Periksa koneksi internet."
        } finally {
            loading = false
        }
    }

    fun search(q: String, src: Int = 0) { searchJob?.cancel(); searchJob = viewModelScope.launch {
        error = null
        if (q.isBlank()) { results = emptyList(); searching = false; return@launch }
        searching = true
        try {
            results = MediaRepository.searchIndie(q.trim())
            Telemetry.log("search", "$src:$q")
        } catch (e: kotlinx.coroutines.CancellationException) { throw e
        } catch (e: Exception) { error = "Pencarian musik gagal. Periksa koneksi lalu coba lagi." }
        searching = false
    } }
    fun clearNotice() { notice = null }

    private fun record(m: MediaItem) {
        viewModelScope.launch {
            val e = dao.get(m.id) ?: m.toEntity()
            dao.upsert(e.copy(lastPlayed = System.currentTimeMillis(), playCount = e.playCount + 1))
        }
        Telemetry.log("play", "${m.title} - ${m.artist}")
    }

    private fun toExo(m: MediaItem) = ExoItem.Builder().setMediaId(m.id).setUri(m.mediaUrl)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(m.title).setArtist(m.artist)
            .setArtworkUri(android.net.Uri.parse(m.coverUrl)).build()).build()

    fun play(item: MediaItem, list: List<MediaItem> = listOf(item)) {
        if (item.id.startsWith("dz_")) {
            notice = "Track preview lama tidak lagi diputar. Cari versi full-length di katalog yang tersedia."
            return
        }
        if (item.type != MediaType.AUDIO) return
        val c = controller ?: return
        queue = (if (list.any { it.id == item.id }) list else listOf(item)).filter { it.type == MediaType.AUDIO && !it.id.startsWith("dz_") }
        val startIndex = queue.indexOfFirst { it.id == item.id }
        if (startIndex < 0) return
        current = item; error = null
        c.setMediaItems(queue.map(::toExo), startIndex, 0L)
        c.prepare(); c.play()
    }
    fun toggle() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun next() { controller?.seekToNextMediaItem() }
    fun prev() { controller?.seekToPreviousMediaItem() }
    fun seek(ms: Long) { controller?.seekTo(ms); position = ms }
    fun toggleShuffle() { shuffle = !shuffle; controller?.shuffleModeEnabled = shuffle }
    fun toggleRepeat() { repeatAll = !repeatAll; controller?.repeatMode = if (repeatAll) Player.REPEAT_MODE_ALL else Player.REPEAT_MODE_OFF }
    fun toggleLike(m: MediaItem) = viewModelScope.launch {
        val e = dao.get(m.id) ?: m.toEntity()
        dao.upsert(e.copy(liked = !e.liked)); Telemetry.log("like", m.title)
    }
    fun createPlaylist(name: String, first: MediaItem? = null) = viewModelScope.launch {
        val id = dao.insertPlaylist(PlaylistEntity(name = name))
        if (first != null) addToPlaylistId(id, first)
    }
    fun addToPlaylist(p: PlaylistEntity, m: MediaItem) = viewModelScope.launch { addToPlaylistId(p.id, m) }
    private suspend fun addToPlaylistId(pid: Long, m: MediaItem) {
        if (dao.get(m.id) == null) dao.upsert(m.toEntity())
        dao.addItem(PlaylistItemEntity(pid, m.id, dao.count(pid)))
    }
    fun deletePlaylist(p: PlaylistEntity) = viewModelScope.launch { dao.clearPlaylist(p.id); dao.deletePlaylist(p.id) }
    fun playlistItems(id: Long) = dao.items(id).map { l -> l.map { it.toDomain() } }
}
