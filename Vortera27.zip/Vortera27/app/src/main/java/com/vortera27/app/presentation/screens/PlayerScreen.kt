package com.vortera27.app.presentation.screens

import android.view.LayoutInflater
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.vortera27.app.domain.model.MediaType
import com.vortera27.app.presentation.PlayerViewModel
import com.vortera27.app.presentation.theme.*
import kotlinx.coroutines.delay

@Composable
fun PlayerScreen(vm: PlayerViewModel, onClose: () -> Unit) {
    val item = vm.current ?: return
    val c = vm.controller
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(1L) }
    LaunchedEffect(c, item) { while (true) { pos = c?.currentPosition ?: 0; dur = (c?.duration ?: 1).coerceAtLeast(1); delay(500) } }
    val showVideo = item.type == MediaType.VIDEO && !vm.audioOnly

    Column(Modifier.fillMaxSize().background(VorteraBackground).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClose) { Icon(Icons.Filled.KeyboardArrowDown, null) }
            Spacer(Modifier.weight(1f)); Text("Sedang Diputar", color = VorteraTextSecondary); Spacer(Modifier.weight(1f))
            Spacer(Modifier.width(48.dp))
        }
        Spacer(Modifier.height(16.dp))
        if (showVideo && c != null) {
            AndroidView({ ctx -> PlayerView(ctx).apply { player = c; useController = false } },
                Modifier.fillMaxWidth().aspectRatio(16 / 9f).clip(RoundedCornerShape(16.dp)),
                update = { it.player = c })
        } else {
            AsyncImage(item.coverUrl, null, Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(20.dp)),
                contentScale = ContentScale.Crop)
        }
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(item.title, style = MaterialTheme.typography.titleLarge)
                Text(item.artist, color = VorteraTextSecondary)
            }
            IconButton({ vm.toggleLike(item) }) {
                Icon(if (item.id in vm.liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, tint = VorteraCyan)
            }
        }
        Slider(pos.toFloat(), { vm.seek(it.toLong()) }, valueRange = 0f..dur.toFloat(),
            colors = SliderDefaults.colors(thumbColor = VorteraCyan, activeTrackColor = VorteraCyan,
                inactiveTrackColor = VorteraSurface))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(pos), color = VorteraTextSecondary); Text(fmt(dur), color = VorteraTextSecondary)
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            IconButton(vm::prev) { Icon(Icons.Filled.SkipPrevious, null, Modifier.size(36.dp)) }
            Box(Modifier.size(72.dp).clip(RoundedCornerShape(36.dp)).background(VorteraGradient).clickable { vm.toggle() },
                contentAlignment = Alignment.Center) {
                Icon(if (vm.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, null,
                    Modifier.size(40.dp), tint = androidx.compose.ui.graphics.Color.Black)
            }
            IconButton(vm::next) { Icon(Icons.Filled.SkipNext, null, Modifier.size(36.dp)) }
        }
        Spacer(Modifier.height(16.dp))
        if (item.type == MediaType.VIDEO) {
            OutlinedButton(vm::toggleAudioOnly) {
                Text(if (vm.audioOnly) "Mode Video" else "Mode Audio (hemat data)", color = VorteraCyan)
            }
        }
    }
}
private fun fmt(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }
