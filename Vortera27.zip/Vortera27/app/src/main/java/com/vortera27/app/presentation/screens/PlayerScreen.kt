package com.vortera27.app.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.vortera27.app.domain.model.MediaType
import com.vortera27.app.presentation.PlayerViewModel
import com.vortera27.app.presentation.theme.*

@Composable
fun PlayerScreen(vm: PlayerViewModel, onClose: () -> Unit) {
    val item = vm.current ?: return
    val c = vm.controller
    val showVideo = item.type == MediaType.VIDEO && !vm.audioOnly
    val liked = item.id in vm.likedIds
    Column(Modifier.fillMaxSize()
        .background(Brush.verticalGradient(listOf(VorteraPurple.copy(alpha = 0.55f), VorteraBackground, VorteraBackground)))
        .pointerInput(Unit) { detectTapGestures { } }.padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClose) { Icon(Icons.Filled.KeyboardArrowDown, null, Modifier.size(32.dp)) }
            Text("SEDANG DIPUTAR", Modifier.weight(1f), color = Color.White, fontSize = 12.sp,
                fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Spacer(Modifier.width(48.dp))
        }
        Spacer(Modifier.height(20.dp))
        if (showVideo && c != null) {
            AndroidView({ ctx -> PlayerView(ctx).apply { player = c; useController = false } },
                Modifier.fillMaxWidth().aspectRatio(16 / 9f).clip(RoundedCornerShape(12.dp)), update = { it.player = c })
        } else {
            AsyncImage(item.coverUrl, null, Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(12.dp)),
                contentScale = ContentScale.Crop)
        }
        Spacer(Modifier.height(28.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(item.title, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(item.artist, color = VorteraTextSecondary, maxLines = 1)
            }
            IconButton({ vm.toggleLike(item) }) {
                Icon(if (liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null,
                    tint = if (liked) VorteraCyan else Color.White, modifier = Modifier.size(28.dp))
            }
        }
        Slider(vm.position.toFloat(), { vm.seek(it.toLong()) }, valueRange = 0f..vm.duration.coerceAtLeast(1L).toFloat(),
            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Color.White, inactiveTrackColor = Color.White.copy(alpha = 0.25f)))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(fmt(vm.position), color = VorteraTextSecondary, fontSize = 12.sp)
            Text(fmt(vm.duration), color = VorteraTextSecondary, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            IconButton(vm::toggleShuffle) { Icon(Icons.Filled.Shuffle, null, tint = if (vm.shuffle) VorteraCyan else Color.White) }
            IconButton(vm::prev) { Icon(Icons.Filled.SkipPrevious, null, Modifier.size(40.dp)) }
            Box(Modifier.size(68.dp).clip(RoundedCornerShape(34.dp)).background(Color.White).clickable { vm.toggle() }, Alignment.Center) {
                if (vm.buffering) CircularProgressIndicator(Modifier.size(32.dp), color = Color.Black, strokeWidth = 3.dp)
                else Icon(if (vm.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, Modifier.size(40.dp), tint = Color.Black)
            }
            IconButton(vm::next) { Icon(Icons.Filled.SkipNext, null, Modifier.size(40.dp)) }
            IconButton(vm::toggleRepeat) { Icon(Icons.Filled.Repeat, null, tint = if (vm.repeatAll) VorteraCyan else Color.White) }
        }
        Spacer(Modifier.height(16.dp))
        if (item.type == MediaType.VIDEO) OutlinedButton(vm::toggleAudioOnly) {
            Text(if (vm.audioOnly) "Mode Video" else "Mode Audio (hemat data)", color = VorteraCyan)
        }
    }
}
private fun fmt(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }
