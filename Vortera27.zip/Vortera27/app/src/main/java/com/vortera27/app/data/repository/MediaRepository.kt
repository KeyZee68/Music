package com.vortera27.app.data.repository

import com.vortera27.app.data.remote.AudiusApi
import com.vortera27.app.data.remote.AudiusTrack
import com.vortera27.app.domain.model.MediaItem
import com.vortera27.app.domain.model.MediaType

/** Musik: Audius API (lagu penuh, gratis, tanpa API key). Video: sampel lokal. */
object MediaRepository {
    private val api = AudiusApi.instance

    private fun AudiusTrack.toDomain(): MediaItem? {
        val i = id ?: return null
        return MediaItem(i, title ?: "Tanpa judul", user?.name ?: "Unknown",
            artwork?.big ?: artwork?.small ?: "https://picsum.photos/seed/$i/400",
            "https://api.audius.co/v1/tracks/$i/stream?app_name=${AudiusApi.APP}",
            MediaType.AUDIO, (duration ?: 0L) * 1000)
    }

    suspend fun trending(): List<MediaItem> =
        api.trending(AudiusApi.APP, 25).data.orEmpty().mapNotNull { it.toDomain() }

    suspend fun search(q: String): List<MediaItem> =
        api.search(q, AudiusApi.APP, 25).data.orEmpty().mapNotNull { it.toDomain() }

    val videos = listOf(
        v("v1", "Big Buck Bunny", "Blender", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"),
        v("v2", "Elephants Dream", "Blender", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4")
    )
    private fun v(id: String, t: String, ar: String, url: String) =
        MediaItem(id, t, ar, "https://picsum.photos/seed/$id/400", url, MediaType.VIDEO, 0)
}
