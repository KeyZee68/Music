package com.vortera27.app.data.repository

import com.vortera27.app.data.remote.*
import com.vortera27.app.domain.model.MediaItem
import com.vortera27.app.domain.model.MediaType

/**
 * Audio catalogue based on Audius. Only full stream URLs are exposed to the player;
 * short-form preview providers are intentionally excluded from playback results.
 */
object MediaRepository {
    private val audius = AudiusApi.instance

    private fun AudiusTrack.toDomain(): MediaItem? {
        val i = id ?: return null
        return MediaItem(i, title ?: "Tanpa judul", user?.name ?: "Unknown",
            artwork?.big ?: artwork?.small ?: "https://picsum.photos/seed/$i/400",
            "https://api.audius.co/v1/tracks/$i/stream?app_name=${AudiusApi.APP}", MediaType.AUDIO, (duration ?: 0L) * 1000)
    }

    // Hanya track Audius yang menyediakan stream lagu penuh yang dimasukkan ke katalog putar.
    // Deezer preview 30 detik sengaja tidak ditampilkan sebagai lagu yang bisa diputar.
    suspend fun chart() = audius.trending(AudiusApi.APP, 30).data.orEmpty().mapNotNull { it.toDomain() }
    suspend fun viral(): List<MediaItem> =
        audius.search("viral tiktok", AudiusApi.APP, 30).data.orEmpty().mapNotNull { it.toDomain() }
    suspend fun indo(): List<MediaItem> =
        audius.search("indonesia", AudiusApi.APP, 30).data.orEmpty().mapNotNull { it.toDomain() }
    suspend fun indie() = audius.trending(AudiusApi.APP, 30).data.orEmpty().mapNotNull { it.toDomain() }
    suspend fun searchIndie(q: String) = audius.search(q, AudiusApi.APP, 30).data.orEmpty().mapNotNull { it.toDomain() }
}
