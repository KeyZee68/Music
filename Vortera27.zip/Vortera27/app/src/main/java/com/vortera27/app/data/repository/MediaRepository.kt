package com.vortera27.app.data.repository

import android.text.Html
import com.vortera27.app.BuildConfig
import com.vortera27.app.data.remote.*
import com.vortera27.app.domain.model.MediaItem
import com.vortera27.app.domain.model.MediaType

/**
 * Sumber musik:
 *  - Deezer  : katalog sangat besar + chart + playlist viral (cuplikan 30 dtk, bisa diputar di latar belakang)
 *  - YouTube : pencarian resmi (Data API), diputar lewat pemutar embed resmi YouTube (lagu lengkap)
 *  - Audius  : musik independen, lagu penuh
 */
object MediaRepository {
    private val audius = AudiusApi.instance
    private val dz = DeezerApi.instance

    private fun DzTrack.toDomain(): MediaItem? {
        val p = preview?.takeIf { it.isNotBlank() } ?: return null
        val i = id ?: return null
        return MediaItem("dz_$i", title ?: "Tanpa judul", artist?.name ?: "Unknown",
            album?.cover_big ?: album?.cover_medium ?: "https://picsum.photos/seed/dz$i/400", p, MediaType.AUDIO, 30_000)
    }
    private fun AudiusTrack.toDomain(): MediaItem? {
        val i = id ?: return null
        return MediaItem(i, title ?: "Tanpa judul", user?.name ?: "Unknown",
            artwork?.big ?: artwork?.small ?: "https://picsum.photos/seed/$i/400",
            "https://api.audius.co/v1/tracks/$i/stream?app_name=${AudiusApi.APP}", MediaType.AUDIO, (duration ?: 0L) * 1000)
    }

    suspend fun chart() = dz.chart(30).data.orEmpty().mapNotNull { it.toDomain() }
    suspend fun searchDeezer(q: String) = dz.search(q, 40).data.orEmpty().mapNotNull { it.toDomain() }
    suspend fun viral(): List<MediaItem> {
        val pl = dz.searchPlaylist("tiktok viral", 5).data.orEmpty().firstOrNull { it.id != null } ?: return emptyList()
        return dz.playlistTracks(pl.id!!, 30).data.orEmpty().mapNotNull { it.toDomain() }
    }
    suspend fun indo(): List<MediaItem> {
        val pl = dz.searchPlaylist("top indonesia", 5).data.orEmpty().firstOrNull { it.id != null } ?: return emptyList()
        return dz.playlistTracks(pl.id!!, 30).data.orEmpty().mapNotNull { it.toDomain() }
    }
    suspend fun indie() = audius.trending(AudiusApi.APP, 25).data.orEmpty().mapNotNull { it.toDomain() }
    suspend fun searchIndie(q: String) = audius.search(q, AudiusApi.APP, 25).data.orEmpty().mapNotNull { it.toDomain() }

    suspend fun searchYoutube(q: String): List<MediaItem> {
        if (BuildConfig.YT_KEY.isBlank()) throw IllegalStateException("no key")
        return YouTubeApi.instance.search("snippet", "video", "10", 20, q, BuildConfig.YT_KEY.trim()).items.orEmpty().mapNotNull {
            val vid = it.id?.videoId ?: return@mapNotNull null
            val s = it.snippet
            MediaItem("yt_$vid", Html.fromHtml(s?.title ?: "Tanpa judul", Html.FROM_HTML_MODE_LEGACY).toString(),
                s?.channelTitle ?: "YouTube", s?.thumbnails?.high?.url ?: s?.thumbnails?.medium?.url ?: "", vid, MediaType.YOUTUBE, 0)
        }
    }

    val videos = listOf(
        v("v1", "Big Buck Bunny", "Blender", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"),
        v("v2", "Elephants Dream", "Blender", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4")
    )
    private fun v(id: String, t: String, ar: String, url: String) =
        MediaItem(id, t, ar, "https://picsum.photos/seed/$id/400", url, MediaType.VIDEO, 0)
}
