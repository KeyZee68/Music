plugins { id("com.android.application"); id("org.jetbrains.kotlin.android"); id("com.google.devtools.ksp") }
val vc = (project.findProperty("vc") as String?)?.toIntOrNull() ?: 1
val sbUrl = (project.findProperty("sburl") as String?) ?: ""
val sbKey = (project.findProperty("sbkey") as String?) ?: ""
val ytKey = (project.findProperty("ytkey") as String?) ?: ""
android {
    namespace = "com.vortera27.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.vortera27.app"; minSdk = 26; targetSdk = 34
        versionCode = vc; versionName = "1.$vc"
        buildConfigField("String", "SUPABASE_URL", "\"$sbUrl\"")
        buildConfigField("String", "SUPABASE_KEY", "\"$sbKey\"")
        buildConfigField("String", "YT_KEY", "\"$ytKey\"")
    }
    signingConfigs {
        create("vortera") {
            storeFile = file("vortera.jks"); storePassword = "vortera27"
            keyAlias = "vortera"; keyPassword = "vortera27"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("vortera") }
        getByName("release") { signingConfig = signingConfigs.getByName("vortera"); isMinifyEnabled = false }
    }
    lint { checkReleaseBuilds = false; abortOnError = false }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
    buildFeatures { compose = true; buildConfig = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-session:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-gson:2.11.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")
}
