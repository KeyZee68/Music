# Vortera27 audio architecture

## Audio-only scope
The video catalogue, video player screen, YouTube embed player, and picture-in-picture flow have been removed. The app now exposes audio items only. `VIDEO` and `YOUTUBE` enum values remain solely so an existing Room database can deserialize legacy rows; DAO queries hide those legacy rows.

## Catalog providers
- Deezer is used for catalog metadata and the preview URLs returned by its public API. These previews are commonly limited to about 30 seconds.
- Audius is used for independent music discovery and its official track stream endpoint, subject to the provider's catalog, availability, and rights.

Search mode "Semua sumber" queries Deezer and Audius concurrently and merges unique results. It cannot promise that every song in existence is available. A provider's metadata search result is not a grant of full-track streaming rights. Do not add unofficial extraction or stream-ripping of subscription services.

## Playback
AndroidX Media3 ExoPlayer is hosted in `VorteraPlaybackService` with a MediaLibrarySession. The service is the playback owner; the Compose UI controls it through MediaController. This is the correct basis for background playback, notification controls, lock-screen controls, and headset/media-button integration. Device/OEM battery restrictions and notification permission can still affect behavior and must be tested on physical devices.

## GitHub Actions
`.github/workflows/build.yml` builds a debug APK on pushes and pull requests. On a `v*` tag it also builds an unsigned release APK and attaches it to a GitHub Release. For production distribution, configure release signing with a private keystore stored as GitHub Actions secrets; never commit the keystore or its passwords to the repository.
