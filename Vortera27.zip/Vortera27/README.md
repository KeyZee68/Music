# Vortera27 — audio-only streaming build

## What changed
- Removed the video catalogue, video player UI, Picture-in-Picture path, and embedded YouTube player.
- Removed Deezer 30-second previews from playable results. Legacy `dz_` preview entries already saved on a device are blocked from playback.
- Search, trending, Indonesia, and viral discovery now use Audius full-stream tracks only.
- Home catalogue requests run concurrently to reduce initial loading time.
- Updated GitHub Actions to build when `Vortera27.zip` or `Vortera27/**` changes and upload the release APK as an artifact.
- Removed the Android signing keystore from source control. Release signing must use GitHub Actions secrets.

## Important catalogue limitation
This build can play full-length tracks that are available for streaming through Audius. Audius is not a complete licensed catalogue of every major-label release. It cannot guarantee every famous artist, every viral track, or every song worldwide. Tracks with artist-imposed alternative restrictions may also be unavailable. No implementation can truthfully promise “all songs” without distribution/streaming agreements with the relevant rightsholders or a licensed provider plan.

YouTube Data API is metadata/search only; it does not grant a right to extract audio. Deezer preview URLs are short previews and are deliberately not used as full songs. Spotify Web API also does not provide arbitrary full-track audio files to third-party apps.

## GitHub Actions setup
Create these repository Actions secrets:
- `ANDROID_KEYSTORE_BASE64`: base64 encoding of the existing release `.jks` file.
- `ANDROID_KEYSTORE_PASSWORD`: keystore password.
- `ANDROID_KEY_ALIAS`: signing key alias.
- `ANDROID_KEY_PASSWORD`: signing key password.
- `SUPABASE_URL` and `SUPABASE_KEY` are optional telemetry settings.

For the existing key, use the original project copy of `app/vortera.jks` (keep it private). On Linux/macOS:
```bash
base64 -w 0 app/vortera.jks
```
On macOS if `-w` is unsupported:
```bash
base64 app/vortera.jks | tr -d '\n'
```
Copy the output into the `ANDROID_KEYSTORE_BASE64` secret. Do not commit the `.jks` file or paste its contents into chat. Keep the original key and credentials backed up: losing them prevents in-place updates for users who installed APKs signed with that key.

The workflow expects the project folder at `Vortera27/` or a `Vortera27.zip` at the repository root. It builds `assembleRelease`, uploads an APK artifact, and creates a GitHub Release on pushes to `main`.

## Playback note
The Android app uses AndroidX Media3 ExoPlayer in a `MediaLibraryService`. Actual background playback/notification behavior still needs an on-device test across Android versions and OEM battery restrictions.
